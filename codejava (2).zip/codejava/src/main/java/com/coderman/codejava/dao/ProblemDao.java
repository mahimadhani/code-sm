package com.coderman.codejava.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coderman.codejava.model.Problem;

@Repository
public interface ProblemDao extends JpaRepository<Problem,Long>{

}
