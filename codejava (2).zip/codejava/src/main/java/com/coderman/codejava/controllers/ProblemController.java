package com.coderman.codejava.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coderman.codejava.model.Problem;
import com.coderman.codejava.service.ProblemService;

@RestController
public class ProblemController {

	@Autowired
	ProblemService pService;
	
	@GetMapping("/getAllProblems")
	public List<Problem> getAllProblem(){
		List<Problem> problem=pService.getAllProblems();
		return problem;
	}
}
