package com.coderman.codejava.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coderman.codejava.dao.ProblemDao;
import com.coderman.codejava.model.Problem;

@Service
public class ProblemService {

	@Autowired
	ProblemDao pdao;
	
	public List<Problem> getAllProblems(){
		
		List<Problem> problems=pdao.findAll();
		return problems;
	}
}
